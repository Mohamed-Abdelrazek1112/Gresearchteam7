import webhandler

class QuerySolver(object):
    def __init__(self):
        pass

    def answer_query(self, query):
        """Answer a query"""
        # TODO: add your code here
        return 85
